package Pharmacie;


public class Pharmacien extends Personne {
private String salary;
	
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary= salary;
	}
	
	public Pharmacien(int id, String firstName, String lastName,String email,int tel, String salary) {
		super (id , firstName, lastName,email,tel);
		this.salary= salary;
	}
	public Pharmacien() {
		
	}
	
	@Override
	public String toString() {
		return super.toString() + "\n Salaire: " + salary;
	}
	
	

	
	
}
